package com.jeejava.spring.conditional.on.clazz;

public class SpringService {

}
