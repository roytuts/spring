package com.jeejava.spring.conditional.on.missing.bean;

public class RequiredBean {

}
