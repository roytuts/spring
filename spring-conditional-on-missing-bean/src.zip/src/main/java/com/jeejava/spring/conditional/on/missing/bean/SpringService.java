package com.jeejava.spring.conditional.on.missing.bean;

import org.springframework.stereotype.Service;

//@Service
public class SpringService {

}
