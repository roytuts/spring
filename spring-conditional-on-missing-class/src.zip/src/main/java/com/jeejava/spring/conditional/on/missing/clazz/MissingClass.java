package com.jeejava.spring.conditional.on.missing.clazz;

public class MissingClass {

}
